// resources/js/Layouts/AppShell.jsx

import React, { useMemo, useState } from "react";
import { Link, usePage } from "@inertiajs/react";
import { getNavItems } from "@/nav/navItems";

function classNames(...xs) {
  return xs.filter(Boolean).join(" ");
}

export default function AppShell({ title, children }) {
  const { auth } = usePage().props;
  const role = auth?.user?.role ?? "user";

  const nav = useMemo(() => getNavItems(role), [role]);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900">
      {/* Mobile topbar */}
      <div className="sticky top-0 z-40 border-b border-zinc-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
          <button
            className="inline-flex items-center justify-center rounded-lg border border-zinc-200 px-3 py-2 text-sm hover:bg-zinc-50"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            ☰
          </button>

          <div className="flex-1">
            <div className="text-sm font-semibold">DBOOKING</div>
            <div className="text-xs text-zinc-500">{title ?? "Dashboard"}</div>
          </div>

          <div className="flex items-center gap-2">
            <span className="rounded-full bg-zinc-100 px-2 py-1 text-xs text-zinc-700">
              role: {role}
            </span>
            <span className="text-sm text-zinc-700">
              {auth?.user?.name ?? "Guest"}
            </span>
          </div>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/30"
            onClick={() => setMobileOpen(false)}
          />
          <div className="absolute left-0 top-0 h-full w-[320px] bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-3">
              <div className="font-semibold">Navigation</div>
              <button
                className="rounded-lg border border-zinc-200 px-3 py-2 text-sm hover:bg-zinc-50"
                onClick={() => setMobileOpen(false)}
              >
                ✕
              </button>
            </div>
            <Sidebar nav={nav} onNavigate={() => setMobileOpen(false)} />
          </div>
        </div>
      )}

      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-4 py-6 lg:grid-cols-[280px_1fr]">
        {/* Desktop sidebar */}
        <div className="hidden lg:block">
          <div className="sticky top-[72px] rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
            <div className="mb-4">
              <div className="text-sm font-semibold">DBOOKING</div>
              <div className="text-xs text-zinc-500">App Navigation</div>
            </div>
            <Sidebar nav={nav} />
          </div>
        </div>

        {/* Content */}
        <div className="space-y-4">
          <div className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm">
            <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-lg font-semibold">{title ?? "Page"}</h1>
                <p className="text-sm text-zinc-500">
                  RED1-orientiertes Layout (hell, Karten, klare Typo).
                </p>
              </div>
              <div className="mt-3 flex gap-2 sm:mt-0">
                <Link
                  href="/ui-test"
                  className="rounded-lg border border-zinc-200 px-3 py-2 text-sm hover:bg-zinc-50"
                >
                  UI Test
                </Link>
                <Link
                  href="/dashboard"
                  className="rounded-lg bg-zinc-900 px-3 py-2 text-sm text-white hover:bg-zinc-800"
                >
                  Dashboard
                </Link>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

function Sidebar({ nav, onNavigate }) {
  const currentUrl = usePage().url;

  return (
    <nav className="space-y-5">
      {nav.map((section) => (
        <div key={section.section}>
          <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
            {section.section}
          </div>
          <div className="space-y-1">
            {section.items.map((item) => {
              const active = currentUrl === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={onNavigate}
                  className={classNames(
                    "block rounded-lg px-3 py-2 text-sm",
                    active
                      ? "bg-zinc-900 text-white"
                      : "text-zinc-700 hover:bg-zinc-50 hover:text-zinc-900"
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );
}