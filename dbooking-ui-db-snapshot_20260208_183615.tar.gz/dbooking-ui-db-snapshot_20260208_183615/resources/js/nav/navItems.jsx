export function getNavItems(role = "user") {
    const items = [
      { label: "Dashboard", href: "/dashboard" },
      { label: "Bookings", href: "/bookings" },
      { label: "FAQ", href: "/faq" },
    ];
  
    if (role === "host" || role === "admin") {
      items.push({ label: "Host: Events", href: "/host/events" });
    }
  
    if (role === "admin") {
      items.push({ label: "Admin: Reporting", href: "/admin/reporting" });
    }
  
    return items;
  }