import React from "react";
import AppShell from "@/Layouts/AppShell";

export default function UiTest({ message, serverTime }) {
  return (
    <AppShell title="UI Test">
      <div className="space-y-2">
        <div className="text-sm text-zinc-600">Message</div>
        <div className="rounded-xl bg-zinc-50 p-4 text-sm">{message}</div>

        <div className="text-sm text-zinc-600">Server time</div>
        <div className="rounded-xl bg-zinc-50 p-4 text-sm">{serverTime}</div>
      </div>
      <div style={{ padding: 24 }}>
      <h1>UI Test</h1>
      <p>{message}</p>
      <p>{serverTime}</p>
    </div>
    </AppShell>
  );
}